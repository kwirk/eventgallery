<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.joomla help
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

jimport('joomla.utilities.utility');
/*
 *
 * @package     Joomla.Plugin
 * @subpackage  Content.pagebreak
 * @since       1.6
 */
class PlgContentEventgallery_help extends JPlugin
{

	/**
	 * @param   string	The context of the content being passed to the plugin.
	 * @param   object	The article object.  Note $article->text is also available
	 * @param   object	The article params
	 * @param   integer  The 'page' number
	 *
	 * @return  void
	 * @since   1.6
	 */
	public function onContentPrepare($context, &$row, &$params, $page = 0)
	{



		$canProceed = $context == 'com_content.article';
		if (!$canProceed)
		{
			return;
		}

		$document =& JFactory::getDocument();	
	
	    $css=JURI::base().'administrator/components/com_eventgallery/media/css/manual.css';
		$document->addStyleSheet($css);	

		$found = preg_match_all("/{markdown:.*}/", $row->text, $matches);
		if (!$found) {
			return true;
		}

		foreach($matches[0] as $match) {

			include_once JPATH_ADMINISTRATOR.'/components/com_eventgallery/helpers/php_markdown_extra/markdown.php';
			$file = substr($match, 10, strlen($match)-11);
			

			if (substr($file, strlen($file)-3)!='.md') {
				break;			 
			} 

			$my_html = Markdown(file_get_contents($file));
			//fix links
			$search  = '<img src="img/';
			$replace = '<img class="nosmartresize" src="'.JURI::base().'administrator/components/com_eventgallery/doc/img/';
			$my_html = str_replace($search, $replace, $my_html);
			
			
			$row->text = str_replace($match, $my_html, $row->text);			 

		}


		$toc = $this->createToc($row->text);

		$row->text = '<div  class="row-fluid">
						<div class="span3" id="toc" >'.$toc.'</div>
						<div class="span9" >'.$row->text.'</div>
					</div>
					<script>
					jQuery(document).ready(function() {
						//jQuery(\'body\').scrollspy();  
					});

					</script>
					';



		return true;
	}




	 function createToc(&$input) {

		// <h1 id="foo">ffff</h1>
		preg_match_all('/<H([12]+) id="(.*)">(.*)<\/H[12]+>/i', $input, $headlines);
		//echo "<pre>";
		//print_r($headlines);
		//echo "</pre>";
		$output = '<div data-spy="affi" style="top: 130px;" data-offset-top="130"><ul class="nav nav-list ">'."\n";
		$lastLevel = 1;
		foreach($headlines[0] as $number=>$headline) {
			$currentLevel = $headlines[1][$number];
			/*
			if ($currentLevel>$lastLevel) {
				$output .= '<ul class="nav-list nav">';
			}

			$tempLastLevel = $currentLevel;			
			while ($currentLevel<$lastLevel) {
				$output .= "</ul>\n";
				$currentLevel++;
			}*/

			
			$output .= '<li class="level'.$currentLevel.'"><a class="anchor-tag" href="#'.$headlines[2][$number].'">'.$headlines[3][$number].'</a></li>'."\n";			

			//$lastLevel = $tempLastLevel;
		}

		/*while ($lastLevel>0) {
			$output .= "</ul>\n";
			$lastLevel--;
		}*/

		$output .="</ul></div>\n";

		return $output;

	}

	

}
